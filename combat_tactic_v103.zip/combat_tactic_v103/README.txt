######################
### About this mod ###
######################
#
# This mod was created in May 2018 by Sweet Lane.
# The goal is to give a bit more control to a player over the battles.
# Mechanics is very simple: you can start an event chain via special decision,
# which allows you to choose the tactic you want to have in each specific phase
# of the battle.
#
# You will get special traits (they are named respectivly to the tactic you choose).
# The tooltip shows you effects you will have with those tactics.
# Those traits add 100x multiplier to chosen tactics, which is usually enough to 
# override usual chaotic behavior of the tactic engine.
#
# The decision is limited to your character so you will need to risk your life on the 
# battlefield in order to get all the benefits (although you can cheat with console
# and add those traits to your commanders).
#
# Additionally, this mod allows cultural specific tactics for characters with special combat traits:
#
# - Light foot leader - Massive longbow tactic;
# - Heavy foot leader - Schiltron formation; Pike column advance;
# - Cavalry leader - Retreat and ambush; Couched lance charge; Embolon;
# - Desert terrain expert - Desert ambush;
# - Mountain expert - Mountain ambush.
#
# The last update was on October 2018. Since then I've never updated it (new updates make me sad,
# so I still stick to 2.6.3 version with dishabled reaper due DLC). 
# Feel free to use it, or to adopt and maintain it in future!
#
######################